import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/api/users')
      .then(res => setUsuarios(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div style={{ padding: '1rem' }}>
      <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>Lista de Usuarios</h1>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginTop: '1rem' }}>
        {usuarios.map((user, idx) => (
          <div key={idx} style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '10px', width: '250px' }}>
            <img src={user.foto} alt="Foto" style={{ borderRadius: '50%', marginBottom: '1rem' }} />
            <p><strong>Nombre:</strong> {user.nombre}</p>
            <p><strong>Género:</strong> {user.genero}</p>
            <p><strong>Ubicación:</strong> {user.ubicacion}</p>
            <p><strong>Email:</strong> {user.correo}</p>
            <p><strong>Fecha de Nacimiento:</strong> {new Date(user.fechaNacimiento).toLocaleDateString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
